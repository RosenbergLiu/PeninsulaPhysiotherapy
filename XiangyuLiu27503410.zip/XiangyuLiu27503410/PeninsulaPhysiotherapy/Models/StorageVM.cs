﻿namespace PeninsulaPhysiotherapy.Models
{
    public class StorageVM
    {

    }
}
